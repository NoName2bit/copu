# AGENTS.md

## Purpose

This is a room availability checker prototype. A user picks a room and time range, and the app decides whether that booking is allowed under rules AC1–AC6. It only checks — it never saves a booking.

## Structure

- `src/lib/booking.ts` — holds the pure booking rules (`canBook`, `findConflict`, and the `Booking` type) and is the single source of truth for AC1–AC6.
- `src/lib/booking.test.ts` — the Vitest suite covering those rules.
- `src/App.tsx` — UI only plus fixture data.
- `src/index.css` — styling.

## Constraints

Preserve AC1–AC6; no backend, login or booking creation.

The acceptance criteria (AC1–AC6):

- AC1: Accept a candidate interval only when `0 <= start < end <= 1440` and the start is after the supplied current time.
- AC2: Reject bookings longer than 120 minutes.
- AC3: Reject the request when the selected room is blocked.
- AC4: Reject any interval overlapping an existing booking.
- AC5: Allow intervals whose endpoints touch an existing booking.
- AC6: Show a clear Available or Unavailable decision without changing existing booking data.

## Engineering rules

- Every booking decision must go through `canBook`; the UI must never re-implement the rules.
- The overlap check must exist in exactly one place — `findConflict` — and must not be duplicated.
- Touching bookings (one ends where the next starts) are not an overlap.
- The booking logic stays pure: no React, DOM, or `Date.now()` inside `booking.ts`.
- Prefer pure functions and minimal changes; use at most 2 justified patterns.
- Do not mutate booking fixtures; keep responsive UI feedback.
- Changes should be small, one problem at a time.

## Commands

- Start the app with `npm run dev`.
- Run tests with `npm run test`.
- Typecheck with `npx tsc --noEmit`.
- Build with `npm run build`.

Typecheck, tests, and build must all pass after every change.

## Forbidden changes

- Don't alter AC1–AC6 behavior or edit existing tests just to make them pass.
- Don't rename `canBook` or change its signature.
- Don't add libraries, features, or pages.
- Don't redesign the UI or restructure folders.
- Don't touch files outside the task you're given.

## Verification

Run existing tests and add focused regression tests.
Report changed files, rationale and test evidence.
