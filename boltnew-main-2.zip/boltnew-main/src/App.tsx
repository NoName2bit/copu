import { useMemo, useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  Clock3,
  DoorOpen,
  Info,
  LockKeyhole,
  MapPin,
  Users,
  XCircle,
} from 'lucide-react';
import { canBook, type CanBookReason } from './lib/booking';

type Booking = {
  title: string;
  start: number;
  end: number;
  color: 'blue' | 'amber' | 'slate';
};

type Room = {
  id: string;
  name: string;
  building: string;
  floor: string;
  capacity: number;
  type: string;
  blocked?: boolean;
  bookings: Booking[];
};

type CheckResult = {
  available: boolean;
  title: string;
  detail: string;
  booking?: Booking;
};

const CURRENT_TIME = 630;
const CURRENT_TIME_LABEL = '10:30 AM';

const rooms: Room[] = [
  {
    id: 'oak-214',
    name: 'Oak 214',
    building: 'Oak Hall',
    floor: '2nd floor',
    capacity: 8,
    type: 'Study room',
    bookings: [
      { title: 'Peer tutoring', start: 480, end: 570, color: 'slate' },
      { title: 'Department meeting', start: 780, end: 840, color: 'blue' },
    ],
  },
  {
    id: 'library-3b',
    name: 'Library 3B',
    building: 'Main Library',
    floor: '3rd floor',
    capacity: 6,
    type: 'Quiet study room',
    bookings: [
      { title: 'Research group', start: 690, end: 750, color: 'amber' },
      { title: 'Reserved', start: 900, end: 1020, color: 'slate' },
    ],
  },
  {
    id: 'innovation-lab',
    name: 'Innovation Lab',
    building: 'Foundry Building',
    floor: '1st floor',
    capacity: 20,
    type: 'Collaboration space',
    blocked: true,
    bookings: [],
  },
];

const formatTime = (minutes: number): string => {
  const hour = Math.floor(minutes / 60);
  const minute = minutes % 60;
  const suffix = hour >= 12 ? 'PM' : 'AM';
  const displayHour = hour % 12 || 12;
  return `${displayHour}:${minute.toString().padStart(2, '0')} ${suffix}`;
};

const toMinutes = (value: string): number => {
  const [hours, minutes] = value.split(':').map(Number);
  return hours * 60 + minutes;
};

const REASON_MAP: Record<CanBookReason, { title: string; detail: string }> = {
  'invalid-time': { title: 'Check your time range', detail: 'The end time must be after the start time, within the same day.' },
  'past-time': { title: 'That time has passed', detail: `Choose a start time after ${CURRENT_TIME_LABEL}.` },
  'over-two-hour': { title: 'That request is too long', detail: 'Rooms can be checked for up to 2 hours at a time.' },
  'blocked-room': { title: 'Room unavailable today', detail: 'This room is temporarily blocked for maintenance.' },
  'conflict': { title: 'That time is already reserved', detail: 'This time overlaps an existing booking. Try a time around it.' },
};

const getCheckResult = (room: Room, startValue: string, endValue: string): CheckResult => {
  if (!startValue || !endValue) {
    return { available: false, title: 'Add a start and end time', detail: 'Choose both times to check this room.' };
  }

  const start = toMinutes(startValue);
  const end = toMinutes(endValue);

  const decision = canBook({ start, end, now: CURRENT_TIME, blocked: !!room.blocked, bookings: room.bookings });

  if (decision.available) {
    return { available: true, title: 'Room available', detail: `You can use ${room.name} from ${formatTime(start)} to ${formatTime(end)}.` };
  }

  const reasonInfo = REASON_MAP[decision.reason];

  if (decision.reason === 'conflict') {
    const { booking } = decision;
    return {
      available: false,
      title: reasonInfo.title,
      detail: `${booking.title} runs from ${formatTime(booking.start)} to ${formatTime(booking.end)}. Try a time around it.`,
      booking,
    };
  }

  return { available: false, title: reasonInfo.title, detail: reasonInfo.detail };
};

const initialStart = '11:00';
const initialEnd = '12:00';

function App() {
  const [selectedRoomId, setSelectedRoomId] = useState(rooms[0].id);
  const [start, setStart] = useState(initialStart);
  const [end, setEnd] = useState(initialEnd);
  const [hasChecked, setHasChecked] = useState(true);

  const selectedRoom = rooms.find((room) => room.id === selectedRoomId) ?? rooms[0];
  const result = useMemo(() => getCheckResult(selectedRoom, start, end), [selectedRoom, start, end]);

  const handleCheck = (): void => {
    setHasChecked(true);
  };

  const handleRoomChange = (roomId: string): void => {
    setSelectedRoomId(roomId);
    setHasChecked(false);
  };

  const timelineStart = 8 * 60;
  const timelineEnd = 18 * 60;
  const timelineWidth = timelineEnd - timelineStart;
  const pct = (m: number): number => ((m - timelineStart) / timelineWidth) * 100;

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="topbar-inner">
          <a className="brand" href="#main" aria-label="Campus Space home">
            <span className="brand-mark"><DoorOpen size={17} strokeWidth={2.5} /></span>
            <span>Campus<span>Space</span></span>
          </a>
          <div className="prototype-pill"><span className="status-dot" /> Availability checker</div>
        </div>
      </header>

      <main id="main" className="page-content">
        <section className="hero" aria-labelledby="page-title">
          <div className="eyebrow"><span className="eyebrow-line" /> Room availability</div>
          <h1 id="page-title">Find your next<br /><em>focused hour.</em></h1>
          <p className="hero-copy">Check a campus room before you make plans. Pick a space, choose a time, and we’ll show you what’s possible.</p>
          <div className="current-time"><Clock3 size={15} /><span>Campus time</span><strong>{CURRENT_TIME_LABEL}</strong><span className="time-separator">·</span><span>Thursday, October 8, 2026</span></div>
        </section>

        <div className="workspace">
          <section className="booking-card" aria-labelledby="check-heading">
            <div className="card-heading">
              <div>
                <span className="section-number">01 / 02</span>
                <h2 id="check-heading">Choose a room</h2>
              </div>
              <div className="step-icon"><MapPin size={20} /></div>
            </div>

            <label className="field-label" htmlFor="room">Selected room</label>
            <div className="select-wrap">
              <select id="room" value={selectedRoomId} onChange={(event) => handleRoomChange(event.target.value)}>
                {rooms.map((room) => <option key={room.id} value={room.id}>{room.name} · {room.building}</option>)}
              </select>
              <ChevronDown size={18} aria-hidden="true" />
            </div>

            <div className="room-facts">
              <div><MapPin size={14} /><span>{selectedRoom.building}, {selectedRoom.floor}</span></div>
              <div><Users size={14} /><span>Up to {selectedRoom.capacity} people</span></div>
              <div><DoorOpen size={14} /><span>{selectedRoom.type}</span></div>
            </div>

            <div className="divider" />

            <div className="card-heading time-heading">
              <div>
                <span className="section-number">02 / 02</span>
                <h2>Choose a time</h2>
              </div>
              <div className="step-icon"><CalendarDays size={20} /></div>
            </div>

            <div className="time-grid">
              <div>
                <label className="field-label" htmlFor="start">Starts</label>
                <div className="time-input-wrap"><input id="start" type="time" value={start} onChange={(event) => { setStart(event.target.value); setHasChecked(false); }} /><Clock3 size={17} /></div>
              </div>
              <div className="arrow-between"><ArrowRight size={16} /></div>
              <div>
                <label className="field-label" htmlFor="end">Ends</label>
                <div className="time-input-wrap"><input id="end" type="time" value={end} onChange={(event) => { setEnd(event.target.value); setHasChecked(false); }} /><Clock3 size={17} /></div>
              </div>
            </div>
            <p className="helper-text"><Info size={14} /> Up to 2 hours · Start after {CURRENT_TIME_LABEL}</p>

            <button className="check-button" type="button" onClick={handleCheck}>Check availability <ArrowRight size={18} /></button>
            <p className="privacy-note"><LockKeyhole size={13} /> This is a check only. Nothing will be booked.</p>
          </section>

          <section className={`result-card ${hasChecked ? (result.available ? 'result-available' : 'result-unavailable') : 'result-idle'}`} aria-live="polite" aria-labelledby="result-heading">
            <div className="result-topline"><span>Availability result</span><span className="result-room">{selectedRoom.name}</span></div>
            {!hasChecked ? (
              <div className="idle-result">
                <div className="result-symbol"><Clock3 size={27} /></div>
                <h2 id="result-heading">Ready when you are</h2>
                <p>Choose a room and time, then check to see if it’s free.</p>
              </div>
            ) : (
              <div className="decision-result">
                <div className="result-symbol">{result.available ? <CheckCircle2 size={29} /> : <XCircle size={29} />}</div>
                <div className="decision-label">{result.available ? 'Available' : 'Unavailable'}</div>
                <h2 id="result-heading">{result.title}</h2>
                <p>{result.detail}</p>
                {!result.available && result.booking && <div className="conflict-callout"><AlertCircle size={16} /><span>Conflict: {formatTime(result.booking.start)} – {formatTime(result.booking.end)}</span></div>}
                {result.available && <div className="available-callout"><Check size={16} /><span>No existing bookings in this window</span></div>}
              </div>
            )}
            <div className="result-footer"><span>Fictional campus data</span><span>Updated just now</span></div>
          </section>
        </div>

        <section className="schedule-section" aria-labelledby="schedule-heading">
          <div className="schedule-header">
            <div><span className="eyebrow"><span className="eyebrow-line" /> Your room at a glance</span><h2 id="schedule-heading">Today’s schedule</h2></div>
            <span className="schedule-date">Thu · Oct 8 <CalendarDays size={15} /></span>
          </div>
          <div className="schedule-card">
            <div className="schedule-room"><span className="room-avatar">{selectedRoom.name.charAt(0)}</span><div><strong>{selectedRoom.name}</strong><span>{selectedRoom.building}</span></div></div>
            <div className="timeline-wrap">
              <div className="timeline-labels"><span>8 AM</span><span>10 AM</span><span>12 PM</span><span>2 PM</span><span>4 PM</span><span>6 PM</span></div>
              <div className="timeline" role="img" aria-label={`Existing bookings for ${selectedRoom.name}`}>
                <div className="current-marker" style={{ left: `${pct(CURRENT_TIME)}%` }}><span>Now</span></div>
                {selectedRoom.blocked ? <div className="blocked-bar" style={{ left: '0%', width: '100%' }}><LockKeyhole size={14} /> Room blocked</div> : selectedRoom.bookings.map((booking) => <div className={`booking-bar booking-${booking.color}`} key={`${booking.start}-${booking.end}`} style={{ left: `${pct(booking.start)}%`, width: `${pct(booking.end) - pct(booking.start)}%` }} title={`${booking.title}: ${formatTime(booking.start)}–${formatTime(booking.end)}`}>{booking.title}</div>)}
              </div>
            </div>
          </div>
          <p className="schedule-note"><Info size={14} /> Existing bookings are shown for context. They cannot be changed from this page.</p>
        </section>
      </main>

      <footer className="footer"><span>CampusSpace</span><span>Room planning, made calmer.</span></footer>
    </div>
  );
}

export default App;
