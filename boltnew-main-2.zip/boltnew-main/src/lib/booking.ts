/** Minutes in a 24-hour day; booking endpoints are clamped to [0, 1440]. */
const MINUTES_PER_DAY = 1440;
/** Maximum allowed booking duration in minutes. */
const MAX_BOOKING_MINUTES = 120;

/** A time interval in minutes from midnight (0 = 00:00, 1440 = 24:00). */
export type Booking = { start: number; end: number };

export type CanBookReason =
  | 'invalid-time'
  | 'past-time'
  | 'over-two-hour'
  | 'blocked-room'
  | 'conflict';

export type CanBookInput<T extends Booking = Booking> = {
  start: number;
  end: number;
  now: number;
  blocked: boolean;
  bookings: T[];
};

export type CanBookResult<T extends Booking = Booking> =
  | { available: true }
  | { available: false; reason: Exclude<CanBookReason, 'conflict'> }
  | { available: false; reason: 'conflict'; booking: T };

/**
 * Returns the first booking in `bookings` that overlaps the [start, end)
 * interval, or `undefined` if none overlap. Touching endpoints
 * (end == booking.start or start == booking.end) do NOT count as overlaps.
 */
export const findConflict = <T extends Booking>(
  start: number,
  end: number,
  bookings: T[],
): T | undefined => bookings.find((b) => start < b.end && end > b.start);

/**
 * Decides whether a booking request is allowed.
 *
 * Checks are ordered so the most fundamental problem is reported first:
 *   1. invalid-time  — the interval is malformed or out of range
 *   2. past-time     — the start has already passed
 *   3. over-two-hour — the duration exceeds the 2-hour cap
 *   4. blocked-room  — the room is blocked for maintenance
 *   5. conflict      — the interval overlaps an existing booking
 *
 * Pure: never mutates `input.bookings`. On a conflict the offending booking
 * is returned in the result so callers don't need to re-run `findConflict`.
 */
export function canBook<T extends Booking = Booking>(
  input: CanBookInput<T>,
): CanBookResult<T> {
  const { start, end, now, blocked, bookings } = input;

  if (start < 0 || start >= end || end > MINUTES_PER_DAY) {
    return { available: false, reason: 'invalid-time' };
  }

  if (start <= now) {
    return { available: false, reason: 'past-time' };
  }

  if (end - start > MAX_BOOKING_MINUTES) {
    return { available: false, reason: 'over-two-hour' };
  }

  if (blocked) {
    return { available: false, reason: 'blocked-room' };
  }

  const conflict = findConflict(start, end, bookings);
  if (conflict) {
    return { available: false, reason: 'conflict', booking: conflict };
  }

  return { available: true };
}
