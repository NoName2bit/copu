import { describe, it, expect } from 'vitest';
import { canBook, type CanBookInput, type BookingRejectionReason } from './booking';

const NOW = 540;

const fixture = (overrides: Partial<CanBookInput> = {}): CanBookInput => ({
  start: 660,
  end: 720,
  now: NOW,
  blocked: false,
  bookings: [{ start: 600, end: 660 }],
  ...overrides,
});

const fixtureCopy = (overrides: Partial<CanBookInput> = {}): CanBookInput => {
  const base = fixture(overrides);
  return { ...base, bookings: base.bookings.map((b) => ({ ...b })) };
};

const assertDecision = (
  input: CanBookInput,
  expected: { available: true } | { available: false; reason: string },
) => {
  const snapshot = input.bookings.map((b) => ({ ...b }));
  const result = canBook(input);
  expect(result).toEqual(expected);
  expect(input.bookings).toEqual(snapshot);
};

describe('canBook — AC1: valid interval requires 0 <= start < end <= 1440 and start > now', () => {
  it('accepts when 0 <= start < end <= 1440 and start is after now', () => {
    assertDecision(fixtureCopy({ start: 660, end: 720 }), { available: true });
  });

  it('accepts start at 0 when now is before 0', () => {
    assertDecision(
      fixtureCopy({ now: -1, start: 0, end: 60, bookings: [] }),
      { available: true },
    );
  });

  it('rejects start at 0 when now is 0 (start must be strictly after now)', () => {
    assertDecision(
      fixtureCopy({ now: 0, start: 0, end: 60, bookings: [] }),
      { available: false, reason: 'past-time' },
    );
  });

  it('accepts end at exactly 1440', () => {
    assertDecision(
      fixtureCopy({ now: 1000, start: 1320, end: 1440, bookings: [] }),
      { available: true },
    );
  });

  it('rejects start < 0', () => {
    assertDecision(
      fixtureCopy({ start: -10, end: 30 }),
      { available: false, reason: 'invalid-time' },
    );
  });

  it('rejects start == end', () => {
    assertDecision(
      fixtureCopy({ start: 700, end: 700 }),
      { available: false, reason: 'invalid-time' },
    );
  });

  it('rejects end < start', () => {
    assertDecision(
      fixtureCopy({ start: 700, end: 650 }),
      { available: false, reason: 'invalid-time' },
    );
  });

  it('rejects end > 1440', () => {
    assertDecision(
      fixtureCopy({ now: 1000, start: 1420, end: 1450, bookings: [] }),
      { available: false, reason: 'invalid-time' },
    );
  });

  it('rejects start == now', () => {
    assertDecision(
      fixtureCopy({ now: 540, start: 540, end: 600, bookings: [] }),
      { available: false, reason: 'past-time' },
    );
  });

  it('rejects start < now', () => {
    assertDecision(
      fixtureCopy({ now: 540, start: 500, end: 560, bookings: [] }),
      { available: false, reason: 'past-time' },
    );
  });

  it('accepts start exactly one minute after now', () => {
    assertDecision(
      fixtureCopy({ now: 540, start: 541, end: 600, bookings: [] }),
      { available: true },
    );
  });
});

describe('canBook — AC2: reject bookings longer than 120 minutes', () => {
  it('accepts exactly 120 minutes', () => {
    assertDecision(
      fixtureCopy({ start: 660, end: 780, bookings: [] }),
      { available: true },
    );
  });

  it('accepts exactly 120 minutes that touches a booking end', () => {
    assertDecision(
      fixtureCopy({ start: 660, end: 780, bookings: [{ start: 600, end: 660 }] }),
      { available: true },
    );
  });

  it('rejects 121 minutes', () => {
    assertDecision(
      fixtureCopy({ start: 660, end: 781, bookings: [] }),
      { available: false, reason: 'over-two-hour' },
    );
  });

  it('rejects 180 minutes', () => {
    assertDecision(
      fixtureCopy({ start: 660, end: 840, bookings: [] }),
      { available: false, reason: 'over-two-hour' },
    );
  });

  it('rejects 121 minutes even when it also overlaps a booking (over-two-hour takes precedence)', () => {
    assertDecision(
      fixtureCopy({ start: 610, end: 732, bookings: [{ start: 600, end: 660 }] }),
      { available: false, reason: 'over-two-hour' },
    );
  });
});

describe('canBook — AC3: reject when room is blocked', () => {
  it('rejects a valid interval when blocked is true', () => {
    assertDecision(
      fixtureCopy({ blocked: true }),
      { available: false, reason: 'blocked-room' },
    );
  });

  it('rejects a blocked room even with no existing bookings', () => {
    assertDecision(
      fixtureCopy({ blocked: true, bookings: [] }),
      { available: false, reason: 'blocked-room' },
    );
  });

  it('rejects with blocked-room even when a conflict also exists (blocked takes precedence)', () => {
    assertDecision(
      fixtureCopy({ now: 500, start: 610, end: 650, blocked: true, bookings: [{ start: 600, end: 660 }] }),
      { available: false, reason: 'blocked-room' },
    );
  });
});

describe('canBook — AC4: reject any interval overlapping an existing booking', () => {
  const existing = [{ start: 600, end: 660 }];

  it('rejects interval fully inside the booking', () => {
    assertDecision(
      fixtureCopy({ now: 500, start: 610, end: 650, bookings: existing }),
      { available: false, reason: 'conflict' },
    );
  });

  it('rejects interval that starts inside and ends after', () => {
    assertDecision(
      fixtureCopy({ now: 500, start: 650, end: 700, bookings: existing }),
      { available: false, reason: 'conflict' },
    );
  });

  it('rejects interval that starts before and ends inside', () => {
    assertDecision(
      fixtureCopy({ now: 500, start: 580, end: 620, bookings: existing }),
      { available: false, reason: 'conflict' },
    );
  });

  it('rejects interval that fully contains the booking', () => {
    assertDecision(
      fixtureCopy({ now: 500, start: 590, end: 670, bookings: existing }),
      { available: false, reason: 'conflict' },
    );
  });

  it('rejects interval identical to the booking (start == booking.start, end == booking.end)', () => {
    assertDecision(
      fixtureCopy({ now: 500, start: 600, end: 660, bookings: existing }),
      { available: false, reason: 'conflict' },
    );
  });

  it('rejects interval that ends exactly at booking.end but starts before booking.start', () => {
    assertDecision(
      fixtureCopy({ now: 500, start: 590, end: 660, bookings: existing }),
      { available: false, reason: 'conflict' },
    );
  });

  it('rejects interval overlapping the second of two bookings', () => {
    assertDecision(
      fixtureCopy({
        now: 500,
        start: 670,
        end: 710,
        bookings: [
          { start: 600, end: 660 },
          { start: 680, end: 740 },
        ],
      }),
      { available: false, reason: 'conflict' },
    );
  });

  it('rejects interval that touches first booking end but overlaps the second', () => {
    assertDecision(
      fixtureCopy({
        now: 500,
        start: 660,
        end: 700,
        bookings: [
          { start: 600, end: 660 },
          { start: 680, end: 740 },
        ],
      }),
      { available: false, reason: 'conflict' },
    );
  });
});

describe('canBook — AC5: allow intervals whose endpoints touch an existing booking', () => {
  const existing = [{ start: 600, end: 660 }];

  it('allows end touching the booking start (end == booking.start)', () => {
    assertDecision(
      fixtureCopy({ now: 400, start: 540, end: 600, bookings: existing }),
      { available: true },
    );
  });

  it('allows start touching the booking end (start == booking.end)', () => {
    assertDecision(
      fixtureCopy({ now: 500, start: 660, end: 720, bookings: existing }),
      { available: true },
    );
  });

  it('allows an interval between two bookings touching both', () => {
    assertDecision(
      fixtureCopy({
        now: 500,
        start: 660,
        end: 680,
        bookings: [
          { start: 600, end: 660 },
          { start: 680, end: 740 },
        ],
      }),
      { available: true },
    );
  });
});

describe('canBook — AC6: decision does not change existing booking data', () => {
  it('does not mutate bookings when available', () => {
    assertDecision(
      fixtureCopy({ bookings: [{ start: 600, end: 660 }] }),
      { available: true },
    );
  });

  it('does not mutate bookings when conflict', () => {
    assertDecision(
      fixtureCopy({ now: 500, start: 610, end: 650, bookings: [{ start: 600, end: 660 }] }),
      { available: false, reason: 'conflict' },
    );
  });

  it('does not mutate bookings when blocked-room', () => {
    assertDecision(
      fixtureCopy({ blocked: true, bookings: [{ start: 600, end: 660 }] }),
      { available: false, reason: 'blocked-room' },
    );
  });

  it('does not mutate bookings when invalid-time', () => {
    assertDecision(
      fixtureCopy({ start: 700, end: 650, bookings: [{ start: 600, end: 660 }] }),
      { available: false, reason: 'invalid-time' },
    );
  });

  it('does not mutate bookings when past-time', () => {
    assertDecision(
      fixtureCopy({ now: 540, start: 500, end: 560, bookings: [{ start: 600, end: 660 }] }),
      { available: false, reason: 'past-time' },
    );
  });

  it('does not mutate bookings when over-two-hour', () => {
    assertDecision(
      fixtureCopy({ start: 660, end: 800, bookings: [{ start: 600, end: 660 }] }),
      { available: false, reason: 'over-two-hour' },
    );
  });

  it('does not mutate bookings with multiple existing bookings', () => {
    assertDecision(
      fixtureCopy({
        now: 500,
        start: 660,
        end: 680,
        bookings: [
          { start: 600, end: 660 },
          { start: 680, end: 740 },
        ],
      }),
      { available: true },
    );
  });

  it('does not reorder bookings supplied out of order', () => {
    assertDecision(
      fixtureCopy({
        now: 500,
        start: 700,
        end: 720,
        bookings: [
          { start: 680, end: 740 },
          { start: 600, end: 660 },
        ],
      }),
      { available: false, reason: 'conflict' },
    );
  });
});

describe('canBook — regression suite for AC1–AC6', () => {
  describe('AC1: 0 <= start < end <= 1440 and start must be strictly after now', () => {
    it('rejects a start far before now as past-time (not invalid-time)', () => {
      assertDecision(
        fixtureCopy({ now: 540, start: 0, end: 60, bookings: [] }),
        { available: false, reason: 'past-time' },
      );
    });

    it('rejects a reversed interval (end < start) as invalid-time', () => {
      assertDecision(
        fixtureCopy({ now: 100, start: 720, end: 660, bookings: [] }),
        { available: false, reason: 'invalid-time' },
      );
    });

    it('rejects end == 0 as invalid-time because start < end is impossible', () => {
      assertDecision(
        fixtureCopy({ now: -10, start: -5, end: 0, bookings: [] }),
        { available: false, reason: 'invalid-time' },
      );
    });
  });

  describe('AC2: reject bookings longer than 120 minutes', () => {
    it('rejects exactly 121 minutes as over-two-hour', () => {
      assertDecision(
        fixtureCopy({ now: 500, start: 660, end: 781, bookings: [] }),
        { available: false, reason: 'over-two-hour' },
      );
    });

    it('accepts exactly 120 minutes as the maximum allowed duration', () => {
      assertDecision(
        fixtureCopy({ now: 500, start: 660, end: 780, bookings: [] }),
        { available: true },
      );
    });
  });

  describe('AC3: reject when the room is blocked', () => {
    it('rejects a blocked room for an otherwise valid interval with no bookings', () => {
      assertDecision(
        fixtureCopy({ now: 500, start: 660, end: 720, blocked: true, bookings: [] }),
        { available: false, reason: 'blocked-room' },
      );
    });

    it('rejects with blocked-room taking precedence over a conflict', () => {
      assertDecision(
        fixtureCopy({
          now: 500,
          start: 610,
          end: 650,
          blocked: true,
          bookings: [{ start: 600, end: 660 }],
        }),
        { available: false, reason: 'blocked-room' },
      );
    });
  });

  describe('AC4: reject any interval that overlaps an existing booking', () => {
    it('rejects when the candidate starts before a booking and ends inside it', () => {
      assertDecision(
        fixtureCopy({
          now: 500,
          start: 590,
          end: 620,
          bookings: [{ start: 600, end: 660 }],
        }),
        { available: false, reason: 'conflict' },
      );
    });

    it('rejects when the candidate starts inside a booking and ends after it', () => {
      assertDecision(
        fixtureCopy({
          now: 500,
          start: 650,
          end: 700,
          bookings: [{ start: 600, end: 660 }],
        }),
        { available: false, reason: 'conflict' },
      );
    });
  });

  describe('AC5: allow intervals whose endpoints touch but do not overlap', () => {
    it('allows end == booking.start (candidate ends where a booking begins)', () => {
      assertDecision(
        fixtureCopy({
          now: 400,
          start: 540,
          end: 600,
          bookings: [{ start: 600, end: 660 }],
        }),
        { available: true },
      );
    });

    it('allows start == booking.end (candidate begins where a booking ends)', () => {
      assertDecision(
        fixtureCopy({
          now: 500,
          start: 660,
          end: 720,
          bookings: [{ start: 600, end: 660 }],
        }),
        { available: true },
      );
    });

    it('allows an interval that touches two bookings on both sides', () => {
      assertDecision(
        fixtureCopy({
          now: 500,
          start: 660,
          end: 680,
          bookings: [
            { start: 600, end: 660 },
            { start: 680, end: 740 },
          ],
        }),
        { available: true },
      );
    });
  });

  describe('AC6: the decision must not change existing booking data', () => {
    it('leaves bookings untouched when the interval is available', () => {
      const input = fixtureCopy({ now: 500, start: 660, end: 720 });
      const snapshot = input.bookings.map((b) => ({ ...b }));
      const result = canBook(input);
      expect(result).toEqual({ available: true });
      expect(input.bookings).toEqual(snapshot);
      expect(input.bookings).toHaveLength(snapshot.length);
    });

    it('leaves bookings untouched when the interval is rejected as conflict', () => {
      const input = fixtureCopy({
        now: 500,
        start: 610,
        end: 650,
        bookings: [{ start: 600, end: 660 }],
      });
      const snapshot = input.bookings.map((b) => ({ ...b }));
      const result = canBook(input);
      expect(result).toEqual({ available: false, reason: 'conflict' });
      expect(input.bookings).toEqual(snapshot);
      expect(input.bookings).toHaveLength(snapshot.length);
    });
  });
});

describe('canBook — refactoring regression: rejection reasons', () => {
  // Guards the single-source-of-truth reason union exported from booking.ts.
  // Every rejection reason canBook may produce must be a member of
  // BookingRejectionReason; if one is added without updating the union,
  // the type assertion below fails to compile and the runtime coverage
  // check fails.
  const reasonsCovered: BookingRejectionReason[] = [
    'invalid-time',
    'past-time',
    'over-two-hour',
    'blocked-room',
    'conflict',
  ];

  it('every reason produced by canBook is a BookingRejectionReason (compile-time)', () => {
    const cases: CanBookInput[] = [
      fixtureCopy({ start: -10, end: 30 }),
      fixtureCopy({ now: 540, start: 540, end: 600, bookings: [] }),
      fixtureCopy({ start: 660, end: 781, bookings: [] }),
      fixtureCopy({ blocked: true }),
      fixtureCopy({ now: 500, start: 610, end: 650, bookings: [{ start: 600, end: 660 }] }),
    ];
    cases.forEach((input) => {
      const result = canBook(input);
      if (!result.available) {
        const reason: BookingRejectionReason = result.reason;
        expect(reasonsCovered).toContain(reason);
      }
    });
  });

  it('rejection reason set is exactly the five documented reasons', () => {
    expect(reasonsCovered).toHaveLength(5);
    expect(new Set(reasonsCovered).size).toBe(5);
  });
});
